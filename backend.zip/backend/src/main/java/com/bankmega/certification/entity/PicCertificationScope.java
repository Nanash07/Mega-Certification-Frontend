package com.bankmega.certification.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;

@Entity
@Table(name = "pic_certification_scopes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class PicCertificationScope {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Relasi ke User (PIC)
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Relasi ke Certification
    @ManyToOne
    @JoinColumn(name = "certification_id", nullable = false)
    private Certification certification;

    // Relasi ke SubField (opsional)
    @ManyToOne
    @JoinColumn(name = "sub_field_id")
    private SubField subField;

    @CreatedDate
    @Column(name = "created_at", updatable = false)
    private Instant createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private Instant updatedAt;
}