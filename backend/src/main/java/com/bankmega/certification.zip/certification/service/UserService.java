package com.bankmega.certification.service;

import com.bankmega.certification.entity.User;
import com.bankmega.certification.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Get all active users (belum di-soft delete)
    public List<User> getAllActiveUsers() {
        return userRepository.findByDeletedAtIsNull();
    }

    // Get user aktif by ID
    public Optional<User> getActiveUserById(Long id) {
        return userRepository.findByIdAndDeletedAtIsNull(id);
    }

    // Create user baru
    public User createUser(User user) {
        user.setCreatedAt(LocalDateTime.now());
        user.setIsActive(true);
        user.setDeletedAt(null);
        // Jangan lupa hash password beneran bro!
        return userRepository.save(user);
    }

    // Update user aktif
    public User updateUser(Long id, User userDetails) {
        User user = userRepository.findByIdAndDeletedAtIsNull(id)
            .orElseThrow(() -> new RuntimeException("User not found or deleted"));

        user.setUsername(userDetails.getUsername());
        user.setEmail(userDetails.getEmail());
        user.setIsActive(userDetails.getIsActive());
        // Update field lain sesuai kebutuhan
        user.setUpdatedAt(LocalDateTime.now());
        return userRepository.save(user);
    }

    // Soft delete user (update deletedAt, bukan hard delete)
    public void softDeleteUser(Long id) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("User not found!"));
        user.setDeletedAt(LocalDateTime.now());
        userRepository.save(user);
    }

    // Optional: Get users yang udah di-soft delete (admin only)
    public List<User> getSoftDeletedUsers() {
        return userRepository.findByDeletedAtIsNotNull();
    }
}
