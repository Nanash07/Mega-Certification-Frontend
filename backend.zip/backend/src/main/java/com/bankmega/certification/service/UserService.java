package com.bankmega.certification.service;

import com.bankmega.certification.dto.UserRequest;
import com.bankmega.certification.dto.UserResponse;
import com.bankmega.certification.entity.Employee;
import com.bankmega.certification.entity.Role;
import com.bankmega.certification.entity.User;
import com.bankmega.certification.exception.ConflictException;
import com.bankmega.certification.exception.NotFoundException;
import com.bankmega.certification.repository.EmployeeRepository;
import com.bankmega.certification.repository.RoleRepository;
import com.bankmega.certification.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepo;
    @Autowired
    private RoleRepository roleRepo;
    @Autowired
    private EmployeeRepository empRepo;

    public List<UserResponse> getAll() {
        return userRepo.findByDeletedAtIsNull().stream().map(this::mapToResponse).toList();
    }

    public UserResponse getById(Long id) {
        return userRepo.findByIdAndDeletedAtIsNull(id)
                .map(this::mapToResponse)
                .orElseThrow(() -> new NotFoundException("User with id " + id + " not found"));
    }

    public UserResponse create(UserRequest req) {
        // Check for duplicate username & email
        if (userRepo.findByUsername(req.getUsername()).isPresent()) {
            throw new ConflictException("Username has already been used and cannot be reused: " + req.getUsername());
        }
        if (userRepo.findByEmail(req.getEmail()).isPresent()) {
            throw new ConflictException("Email has already been used and cannot be reused: " + req.getEmail());
        }

        // Get role by name
        Role role = roleRepo.findByName(req.getRoleName())
                .orElseThrow(() -> new NotFoundException("Role not found: " + req.getRoleName()));

        // Get employee (optional)
        Employee emp = req.getEmployeeId() != null
                ? empRepo.findById(req.getEmployeeId())
                        .orElseThrow(() -> new NotFoundException("Employee with id " + req.getEmployeeId() + " not found"))
                : null;

        User user = User.builder()
                .username(req.getUsername())
                .email(req.getEmail())
                .password(BCrypt.hashpw(req.getPassword(), BCrypt.gensalt()))
                .role(role)
                .employee(emp)
                .isActive(req.getIsActive())
                .isFirstLogin(true)
                .build();

        return mapToResponse(userRepo.save(user));
    }

    public UserResponse update(Long id, UserRequest req) {
        User user = userRepo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new NotFoundException("User with id " + id + " not found"));

        // Validate uniqueness if username/email changed
       if (!user.getUsername().equals(req.getUsername()) &&
                userRepo.findByUsername(req.getUsername()).isPresent()) {
            throw new ConflictException("Username has already been used and cannot be reused: " + req.getUsername());
        }
        if (!user.getEmail().equals(req.getEmail()) &&
                userRepo.findByEmail(req.getEmail()).isPresent()) {
            throw new ConflictException("Email has already been used and cannot be reused: " + req.getEmail());
        }

        user.setUsername(req.getUsername());
        user.setEmail(req.getEmail());

        if (req.getPassword() != null && !req.getPassword().isBlank()) {
            user.setPassword(BCrypt.hashpw(req.getPassword(), BCrypt.gensalt()));
        }

        if (req.getRoleName() != null) {
            Role role = roleRepo.findByName(req.getRoleName())
                    .orElseThrow(() -> new NotFoundException("Role not found: " + req.getRoleName()));
            user.setRole(role);
        }

        if (req.getEmployeeId() != null) {
            Employee emp = empRepo.findById(req.getEmployeeId())
                    .orElseThrow(() -> new NotFoundException("Employee with id " + req.getEmployeeId() + " not found"));
            user.setEmployee(emp);
        }

        user.setIsActive(req.getIsActive());

        return mapToResponse(userRepo.save(user));
    }

    public void softDelete(Long id) {
        User user = userRepo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new NotFoundException("User with id " + id + " not found"));
        user.setDeletedAt(Instant.now());
        userRepo.save(user);
    }

    private UserResponse mapToResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .role(user.getRole() != null ? user.getRole().getName() : null)
                .employeeId(user.getEmployee() != null ? user.getEmployee().getId() : null)
                .isActive(user.getIsActive())
                .isFirstLogin(user.getIsFirstLogin())
                .build();
    }
}