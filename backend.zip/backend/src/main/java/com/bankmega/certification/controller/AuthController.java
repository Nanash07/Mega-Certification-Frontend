package com.bankmega.certification.controller;

import com.bankmega.certification.dto.LoginRequest;
import com.bankmega.certification.dto.LoginResponse;
import com.bankmega.certification.dto.LoginResponse.LoginResponseBuilder;
import com.bankmega.certification.entity.User;
import com.bankmega.certification.entity.Role;
import com.bankmega.certification.repository.UserRepository;
import com.bankmega.certification.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        User user = userRepository.findByUsernameAndDeletedAtIsNull(request.getUsername())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Username not found"));

        if (!Boolean.TRUE.equals(user.getIsActive())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "User tidak aktif");
        }

        if (!BCrypt.checkpw(request.getPassword(), user.getPassword())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Password salah");
        }

        // Ambil single role
        Role role = user.getRole();
        String roleName = role != null ? role.getName() : null;

        // Generate JWT token (kalau JwtUtil lo butuh list, bikin overload ke string aja)
        String token = JwtUtil.generateToken(user.getUsername(), roleName);

        // Response-nya pake .role(roleName)
        LoginResponse resp = ((LoginResponseBuilder) LoginResponse.builder())
                .id(user.getId())
                .username(user.getUsername())
                .role(roleName)
                .email(user.getEmail())
                .isFirstLogin(user.getIsFirstLogin())
                .isActive(user.getIsActive())
                .token(token)
                .build();

        return ResponseEntity.ok(resp);
    }
}
