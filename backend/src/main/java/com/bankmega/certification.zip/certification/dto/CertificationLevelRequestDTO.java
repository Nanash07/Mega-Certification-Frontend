package com.bankmega.certification.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CertificationLevelRequestDTO {
    private Integer level;
    private String name;
    private Long certificationId;
}
