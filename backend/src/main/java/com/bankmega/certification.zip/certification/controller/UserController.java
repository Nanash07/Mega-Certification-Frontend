package com.bankmega.certification.controller;


import com.bankmega.certification.entity.User;
import com.bankmega.certification.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Get all aktif user
    @GetMapping
    public List<User> getAllActiveUsers() {
        return userService.getAllActiveUsers();
    }

    // Get by ID (hanya user aktif)
    @GetMapping("/{id}")
    public User getActiveUserById(@PathVariable Long id) {
        return userService.getActiveUserById(id)
                .orElseThrow(() -> new RuntimeException("User not found or deleted"));
    }

    // Create user baru
    @PostMapping
    public User createUser(@RequestBody User user) {
        return userService.createUser(user);
    }

    // Update user aktif
    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User userDetails) {
        return userService.updateUser(id, userDetails);
    }

    // Soft delete user
    @DeleteMapping("/{id}")
    public void softDeleteUser(@PathVariable Long id) {
        userService.softDeleteUser(id);
    }

    // (Optional) Get user yang udah soft delete (admin only)
    @GetMapping("/deleted")
    public List<User> getSoftDeletedUsers() {
        return userService.getSoftDeletedUsers();
    }
}
