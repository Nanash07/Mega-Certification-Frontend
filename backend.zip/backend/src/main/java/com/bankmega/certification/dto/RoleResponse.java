package com.bankmega.certification.dto;

import lombok.*;

@Getter @Setter @Builder
public class RoleResponse {
    private Long id;
    private String name;
}
