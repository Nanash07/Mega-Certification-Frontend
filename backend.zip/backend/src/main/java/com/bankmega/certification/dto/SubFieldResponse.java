package com.bankmega.certification.dto;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@Builder
public class SubFieldResponse {
    private Long id;
    private String code;
    private String name;
    private Long certificationId;
    private String certificationName;
    private Instant createdAt;
    private Instant updatedAt;
    private Instant deletedAt;
}