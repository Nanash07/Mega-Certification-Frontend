package com.bankmega.certification.dto;

import lombok.Data;

@Data
public class CertificationRequest {
    private String name;
    private String code;
}