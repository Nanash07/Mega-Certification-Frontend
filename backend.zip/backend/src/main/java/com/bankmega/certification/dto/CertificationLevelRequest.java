package com.bankmega.certification.dto;

import lombok.Data;

@Data
public class CertificationLevelRequest {
    private Integer level;
    private String name;
}