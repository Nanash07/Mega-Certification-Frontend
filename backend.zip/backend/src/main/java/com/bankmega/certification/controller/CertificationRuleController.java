package com.bankmega.certification.controller;

import com.bankmega.certification.dto.CertificationRuleRequest;
import com.bankmega.certification.dto.CertificationRuleResponse;
import com.bankmega.certification.service.CertificationRuleService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/certification-rules")
@RequiredArgsConstructor
public class CertificationRuleController {

    private final CertificationRuleService service;

    @GetMapping
    public List<CertificationRuleResponse> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public CertificationRuleResponse getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    public ResponseEntity<CertificationRuleResponse> create(@RequestBody CertificationRuleRequest req) {
        return ResponseEntity.ok(service.create(req));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CertificationRuleResponse> update(
            @PathVariable Long id,
            @RequestBody CertificationRuleRequest req
    ) {
        return ResponseEntity.ok(service.update(id, req));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.softDelete(id);
        return ResponseEntity.noContent().build();
    }
}