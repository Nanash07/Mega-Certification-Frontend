package com.bankmega.certification.entity;

import lombok.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sub_fields")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubField {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "certification_id")
    private Certification certification;

    @Column(length = 100)
    private String name;

    @Column(length = 20)
    private String code;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
