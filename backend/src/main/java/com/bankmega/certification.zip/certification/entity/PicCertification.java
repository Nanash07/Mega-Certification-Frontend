package com.bankmega.certification.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "pic_certifications")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PicCertification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "certification_id")
    private Certification certification;

    @ManyToOne
    @JoinColumn(name = "sub_field_id", nullable = true)
    private SubField subField; // Optional

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
