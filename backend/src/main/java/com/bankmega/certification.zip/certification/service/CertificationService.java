package com.bankmega.certification.service;

import com.bankmega.certification.dto.CertificationRequestDTO;
import com.bankmega.certification.dto.CertificationResponseDTO;
import com.bankmega.certification.entity.Certification;
import com.bankmega.certification.repository.CertificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CertificationService {

    private final CertificationRepository certificationRepo;

    public List<CertificationResponseDTO> getAllCertifications() {
        return certificationRepo.findAll()
            .stream()
            .map(this::toResponseDTO)
            .collect(Collectors.toList());
    }

    public CertificationResponseDTO getCertificationById(Long id) {
        Certification cert = certificationRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Certification not found!"));
        return toResponseDTO(cert);
    }

    public CertificationResponseDTO createCertification(CertificationRequestDTO dto) {
        Certification cert = toEntity(dto);
        Certification saved = certificationRepo.save(cert);
        return toResponseDTO(saved);
    }

    public CertificationResponseDTO updateCertification(Long id, CertificationRequestDTO dto) {
        Certification cert = certificationRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Certification not found!"));
        cert.setName(dto.getName());
        cert.setCode(dto.getCode());
        cert.setIsWajib6bln(dto.getIsWajib6bln());
        cert.setMasaBerlaku(dto.getMasaBerlaku());
        cert.setReminderMonth(dto.getReminderMonth());
        cert.setIsActive(dto.getIsActive());
        Certification saved = certificationRepo.save(cert);
        return toResponseDTO(saved);
    }

    public void deleteCertification(Long id) {
        Certification cert = certificationRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Certification not found!"));
        certificationRepo.delete(cert);
    }

    // ===== Mapping Helpers =====
    private CertificationResponseDTO toResponseDTO(Certification cert) {
        return CertificationResponseDTO.builder()
            .id(cert.getId())
            .name(cert.getName())
            .code(cert.getCode())
            .isWajib6bln(cert.getIsWajib6bln())
            .masaBerlaku(cert.getMasaBerlaku())
            .reminderMonth(cert.getReminderMonth())
            .isActive(cert.getIsActive())
            .createdAt(cert.getCreatedAt())    // tambahin
            .updatedAt(cert.getUpdatedAt())
            .build();
    }

    private Certification toEntity(CertificationRequestDTO dto) {
        return Certification.builder()
            .name(dto.getName())
            .code(dto.getCode())
            .isWajib6bln(dto.getIsWajib6bln())
            .masaBerlaku(dto.getMasaBerlaku())
            .reminderMonth(dto.getReminderMonth())
            .isActive(dto.getIsActive())
            .build();
    }
}