package com.bankmega.certification.repository;

import com.bankmega.certification.entity.PicCertificationScope;
import com.bankmega.certification.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PicCertificationScopeRepository extends JpaRepository<PicCertificationScope, Long> {
    List<PicCertificationScope> findByUser(User user);
}