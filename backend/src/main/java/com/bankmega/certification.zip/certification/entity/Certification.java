package com.bankmega.certification.entity;

import lombok.*;
import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "certifications")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class) // <<< INI PENTING BRO
public class Certification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50)
    private String name;

    @Column(length = 20)
    private String code;

    @Column(name = "is_wajib_6bln")
    private Boolean isWajib6bln;

    @Column(name = "masa_berlaku")
    private Integer masaBerlaku;

    @Column(name = "reminder_month")
    private Integer reminderMonth;

    @CreatedDate
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "is_active")
    private Boolean isActive;

    @OneToMany(mappedBy = "certification")
    private List<SubField> subFields;

    @OneToMany(mappedBy = "certification")
    private List<CertificationLevel> levels;

    @OneToMany(mappedBy = "certification")
    private Set<PicCertification> picCertifications;
}