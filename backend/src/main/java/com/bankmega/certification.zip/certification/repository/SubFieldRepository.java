package com.bankmega.certification.repository;

import com.bankmega.certification.entity.SubField;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubFieldRepository extends JpaRepository<SubField, Long> {
}
