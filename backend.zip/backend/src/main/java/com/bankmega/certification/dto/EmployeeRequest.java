package com.bankmega.certification.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class EmployeeRequest {
    private String nip;
    private String name;
    private String email;
    private String jobTitle;
    private String jobLevel;
    private String unitKerja;
    private LocalDate joinDate;
    private String status;
    private String photoUrl;
}