package com.bankmega.certification.dto;

import lombok.Data;

@Data
public class UserRequest {
    private String username;
    private String email;
    private String password;
    private String roleName;   // pakai nama role (SUPERADMIN, PIC, PEGAWAI)
    private Long employeeId;   // optional
    private Boolean isActive = true;
}