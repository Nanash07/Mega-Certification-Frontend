package com.bankmega.certification.repository;

import com.bankmega.certification.entity.CertificationRule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CertificationRuleRepository extends JpaRepository<CertificationRule, Long> {
    List<CertificationRule> findByDeletedAtIsNull();
    Optional<CertificationRule> findByIdAndDeletedAtIsNull(Long id);
}