package com.bankmega.certification.repository;

import com.bankmega.certification.entity.CertificationLevel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CertificationLevelRepository extends JpaRepository<CertificationLevel, Long> {}
