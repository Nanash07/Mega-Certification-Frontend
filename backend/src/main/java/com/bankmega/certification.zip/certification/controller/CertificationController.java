package com.bankmega.certification.controller;

import com.bankmega.certification.dto.CertificationRequestDTO;
import com.bankmega.certification.dto.CertificationResponseDTO;
import com.bankmega.certification.service.CertificationService;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/certifications")
@RequiredArgsConstructor
public class CertificationController {

    private final CertificationService certificationService;

    @GetMapping
    public List<CertificationResponseDTO> getAllCertifications() {
        return certificationService.getAllCertifications();
    }

    @GetMapping("/{id}")
    public CertificationResponseDTO getCertificationById(@PathVariable Long id) {
        return certificationService.getCertificationById(id);
    }

    @PostMapping
    public CertificationResponseDTO createCertification(@RequestBody CertificationRequestDTO dto) {
        return certificationService.createCertification(dto);
    }

    @PutMapping("/{id}")
    public CertificationResponseDTO updateCertification(@PathVariable Long id,
                                                       @RequestBody CertificationRequestDTO dto) {
        return certificationService.updateCertification(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCertification(@PathVariable Long id) {
        certificationService.deleteCertification(id);
        return ResponseEntity.noContent().build(); // 204 No Content
    }
}