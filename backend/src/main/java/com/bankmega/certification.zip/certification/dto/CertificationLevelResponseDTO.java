package com.bankmega.certification.dto;

import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CertificationLevelResponseDTO {
    private Long id;
    private Integer level;
    private String name;
    private Long certificationId;
    private String certificationName;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
