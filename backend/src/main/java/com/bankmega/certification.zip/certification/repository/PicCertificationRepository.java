package com.bankmega.certification.repository;

import com.bankmega.certification.entity.PicCertification;
import com.bankmega.certification.entity.User;
import com.bankmega.certification.entity.Certification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PicCertificationRepository extends JpaRepository<PicCertification, Long> {
    List<PicCertification> findByUser(User user);
    List<PicCertification> findByCertification(Certification certification);
    List<PicCertification> findByUserId(Long userId);
    List<PicCertification> findByCertificationId(Long certificationId);
    List<PicCertification> findAllByUserId(Long userId);
    List<PicCertification> findAllByCertificationId(Long certificationId);
}
