package com.bankmega.certification.dto;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@Builder
public class CertificationRuleResponse {
    private Long id;

    private Long certificationId;
    private String certificationName;

    private Long levelId;
    private String levelName;

    private Long subFieldId;
    private String subFieldName;

    private Instant createdAt;
    private Instant updatedAt;
}