package com.bankmega.certification.service;

import com.bankmega.certification.dto.PicCertificationScopeRequest;
import com.bankmega.certification.dto.PicCertificationScopeResponse;
import com.bankmega.certification.entity.Certification;
import com.bankmega.certification.entity.PicCertificationScope;
import com.bankmega.certification.entity.SubField;
import com.bankmega.certification.entity.User;
import com.bankmega.certification.exception.NotFoundException;
import com.bankmega.certification.repository.CertificationRepository;
import com.bankmega.certification.repository.PicCertificationScopeRepository;
import com.bankmega.certification.repository.SubFieldRepository;
import com.bankmega.certification.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PicCertificationScopeService {

    @Autowired
    private PicCertificationScopeRepository repo;
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private CertificationRepository certRepo;
    @Autowired
    private SubFieldRepository subFieldRepo;

    public List<PicCertificationScopeResponse> getByUser(Long userId) {
        User user = userRepo.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new NotFoundException("User with id " + userId + " not found"));
        return repo.findByUser(user).stream().map(this::mapToResponse).toList();
    }

    public PicCertificationScopeResponse create(PicCertificationScopeRequest req) {
        User user = userRepo.findByIdAndDeletedAtIsNull(req.getUserId())
                .orElseThrow(() -> new NotFoundException("User with id " + req.getUserId() + " not found"));

        Certification cert = certRepo.findById(req.getCertificationId())
                .orElseThrow(() -> new NotFoundException("Certification with id " + req.getCertificationId() + " not found"));

        SubField subField = req.getSubFieldId() != null
                ? subFieldRepo.findById(req.getSubFieldId())
                        .orElseThrow(() -> new NotFoundException("SubField with id " + req.getSubFieldId() + " not found"))
                : null;

        PicCertificationScope scope = PicCertificationScope.builder()
                .user(user)
                .certification(cert)
                .subField(subField)
                .build();

        return mapToResponse(repo.save(scope));
    }

    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new NotFoundException("PIC Certification scope with id " + id + " not found");
        }
        repo.deleteById(id);
    }

    private PicCertificationScopeResponse mapToResponse(PicCertificationScope scope) {
        return PicCertificationScopeResponse.builder()
                .id(scope.getId())
                .userId(scope.getUser().getId())
                .username(scope.getUser().getUsername())
                .certificationId(scope.getCertification().getId())
                .certificationName(scope.getCertification().getName())
                .subFieldId(scope.getSubField() != null ? scope.getSubField().getId() : null)
                .subFieldName(scope.getSubField() != null ? scope.getSubField().getName() : null)
                .build();
    }
}