package com.bankmega.certification.controller;

import com.bankmega.certification.dto.CertificationLevelRequestDTO;
import com.bankmega.certification.dto.CertificationLevelResponseDTO;
import com.bankmega.certification.service.CertificationLevelService;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/certification-levels")
@RequiredArgsConstructor
public class CertificationLevelController {

    private final CertificationLevelService levelService;

    @GetMapping
    public List<CertificationLevelResponseDTO> getAllLevels() {
        return levelService.getAllLevels();
    }

    @GetMapping("/{id}")
    public CertificationLevelResponseDTO getLevelById(@PathVariable Long id) {
        return levelService.getLevelById(id);
    }

    @PostMapping
    public CertificationLevelResponseDTO createLevel(@RequestBody CertificationLevelRequestDTO dto) {
        return levelService.createLevel(dto);
    }

    @PutMapping("/{id}")
    public CertificationLevelResponseDTO updateLevel(@PathVariable Long id, @RequestBody CertificationLevelRequestDTO dto) {
        return levelService.updateLevel(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        levelService.deleteLevel(id);
        return ResponseEntity.noContent().build(); // 204 kalau sukses
    }
}
