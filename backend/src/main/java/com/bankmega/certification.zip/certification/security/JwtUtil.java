package com.bankmega.certification.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

public class JwtUtil {
    private static final String SECRET = "B4nKMegaGantengP4keJwTSecretKey123!"; // Min 32 char!
    private static final long EXPIRATION_MS = 24 * 60 * 60 * 1000; // 24 jam

    private static final SecretKey SECRET_KEY = Keys.hmacShaKeyFor(SECRET.getBytes());

    // Ekstrak semua claims
    private static Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(SECRET_KEY)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    // Ekstrak claim generic
    public static <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // Ambil username (subject)
    public static String getUsernameFromToken(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    // Ambil roles (array/list) dari JWT
    public static List<String> getRolesFromToken(String token) {
        // Asumsi: roles disimpan sebagai List<String> di claim "roles"
        Object rolesObj = extractClaim(token, claims -> claims.get("roles"));
        if (rolesObj instanceof List<?> list) {
            return list.stream().map(Object::toString).toList();
        }
        return List.of();
    }

    // Cek expired
    private static boolean isTokenExpired(String token) {
        return extractClaim(token, Claims::getExpiration).before(new Date());
    }

    // Generate token: masukkan username + list role
    public static String generateToken(String username, String roleName) {
        return Jwts.builder()
                .subject(username)
                .claim("role", roleName)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + EXPIRATION_MS))
                .signWith(SECRET_KEY)
                .compact();
    }

    // Validasi token (cek username & expired, tanpa UserDetails)
    public static boolean validateToken(String token, String username) {
        try {
            final String usernameInToken = getUsernameFromToken(token);
            return (usernameInToken.equals(username) && !isTokenExpired(token));
        } catch (JwtException | IllegalArgumentException e) {
            System.err.println("Invalid JWT Token: " + e.getMessage());
            return false;
        }
    }
}