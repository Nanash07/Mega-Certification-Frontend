package com.bankmega.certification.service;

import com.bankmega.certification.dto.CertificationLevelRequestDTO;
import com.bankmega.certification.dto.CertificationLevelResponseDTO;
import com.bankmega.certification.entity.Certification;
import com.bankmega.certification.entity.CertificationLevel;
import com.bankmega.certification.repository.CertificationLevelRepository;
import com.bankmega.certification.repository.CertificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CertificationLevelService {

    private final CertificationLevelRepository levelRepo;
    private final CertificationRepository certificationRepo;

    public List<CertificationLevelResponseDTO> getAllLevels() {
        return levelRepo.findAll().stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    public CertificationLevelResponseDTO getLevelById(Long id) {
        CertificationLevel level = levelRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Level not found!"));
        return toResponseDTO(level);
    }

    public CertificationLevelResponseDTO createLevel(CertificationLevelRequestDTO dto) {
        Certification cert = certificationRepo.findById(dto.getCertificationId())
                .orElseThrow(() -> new RuntimeException("Certification not found!"));
        CertificationLevel level = CertificationLevel.builder()
                .level(dto.getLevel())
                .name(dto.getName())
                .certification(cert)
                .build();
        CertificationLevel saved = levelRepo.save(level);
        return toResponseDTO(saved);
    }

    public CertificationLevelResponseDTO updateLevel(Long id, CertificationLevelRequestDTO dto) {
        CertificationLevel level = levelRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Level not found!"));
        Certification cert = certificationRepo.findById(dto.getCertificationId())
                .orElseThrow(() -> new RuntimeException("Certification not found!"));

        level.setLevel(dto.getLevel());
        level.setName(dto.getName());
        level.setCertification(cert);

        CertificationLevel saved = levelRepo.save(level);
        return toResponseDTO(saved);
    }

    public void deleteLevel(Long id) {
        CertificationLevel level = levelRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Certification Level not found!"));
        levelRepo.delete(level);
    }

    private CertificationLevelResponseDTO toResponseDTO(CertificationLevel level) {
        return CertificationLevelResponseDTO.builder()
                .id(level.getId())
                .level(level.getLevel())
                .name(level.getName())
                .certificationId(
                    level.getCertification() != null ? level.getCertification().getId() : null)
                .certificationName(
                    level.getCertification() != null ? level.getCertification().getName() : null)
                .createdAt(level.getCreatedAt())
                .updatedAt(level.getUpdatedAt())
                .build();
    }
}