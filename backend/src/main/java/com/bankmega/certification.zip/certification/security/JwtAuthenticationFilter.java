package com.bankmega.certification.security;

import com.bankmega.certification.entity.User;
import com.bankmega.certification.repository.UserRepository;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private UserRepository userRepository;

    @SuppressWarnings("null")
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String authHeader = request.getHeader("Authorization");
        String token = null;
        String username = null;

        // Ambil token dari header
        if (StringUtils.hasText(authHeader) && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            try {
                username = JwtUtil.getUsernameFromToken(token);
            } catch (JwtException e) {
                // Token invalid/expired
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                return;
            }
        }

        // Set authentication kalau token valid dan context belum diisi
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            User user = userRepository.findByUsernameWithRoleAndDeletedAtIsNull(username).orElse(null);
            if (user != null && JwtUtil.validateToken(token, user.getUsername())) {
                // Single role version
                String roleName = user.getRole() != null ? "ROLE_" + user.getRole().getName() : null;
                var authorities = roleName != null
                        ? List.of(new org.springframework.security.core.authority.SimpleGrantedAuthority(roleName))
                        : List.of();

                @SuppressWarnings("unchecked")
                var auth = new UsernamePasswordAuthenticationToken(
                        user,
                        null,
                        (Collection<? extends GrantedAuthority>) authorities
                );
                auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(auth);
            }
        }

        filterChain.doFilter(request, response);
    }
}
