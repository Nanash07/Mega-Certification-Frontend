package com.bankmega.certification.repository;

import com.bankmega.certification.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // ✅ Only active employees
    List<Employee> findByDeletedAtIsNull();

    Optional<Employee> findByIdAndDeletedAtIsNull(Long id);

    // ✅ Recycle bin
    List<Employee> findByDeletedAtIsNotNull();

    // ✅ Uniqueness check
    Optional<Employee> findByNip(String nip);

    boolean existsByNip(String nip);
}