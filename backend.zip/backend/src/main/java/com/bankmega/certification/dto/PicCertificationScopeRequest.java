package com.bankmega.certification.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PicCertificationScopeRequest {
    private Long userId;
    private Long certificationId;
    private Long subFieldId; // optional
}
