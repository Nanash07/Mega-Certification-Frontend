package com.bankmega.certification.service;

import com.bankmega.certification.dto.EmployeeRequest;
import com.bankmega.certification.dto.EmployeeResponse;
import com.bankmega.certification.entity.Employee;
import com.bankmega.certification.exception.ConflictException;
import com.bankmega.certification.exception.NotFoundException;
import com.bankmega.certification.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repo;

    // ✅ Get all active employees
    public List<EmployeeResponse> getAll() {
        return repo.findByDeletedAtIsNull().stream()
                .map(this::toResponse)
                .toList();
    }

    // ✅ Get employee by ID
    public EmployeeResponse getById(Long id) {
        Employee emp = repo.findById(id)
                .orElseThrow(() -> new NotFoundException("Employee not found"));

        if (emp.getDeletedAt() != null) {
            throw new NotFoundException("Employee with NIP " + emp.getNip() + " is deleted");
        }

        return toResponse(emp);
    }

    // ✅ Create new employee with unique NIP
    public EmployeeResponse create(EmployeeRequest req) {
        if (repo.existsByNip(req.getNip())) {
            throw new ConflictException("NIP " + req.getNip() + " is already used by another employee");
        }

        Employee emp = Employee.builder()
                .nip(req.getNip())
                .name(req.getName())
                .email(req.getEmail())
                .jobTitle(req.getJobTitle())
                .jobLevel(req.getJobLevel())
                .unitKerja(req.getUnitKerja())
                .joinDate(req.getJoinDate())
                .status(req.getStatus())
                .photoUrl(req.getPhotoUrl())
                .build();

        return toResponse(repo.save(emp));
    }

    // ✅ Update employee with NIP check
    public EmployeeResponse update(Long id, EmployeeRequest req) {
        Employee emp = repo.findById(id)
                .orElseThrow(() -> new NotFoundException("Employee not found"));

        if (emp.getDeletedAt() != null) {
            throw new NotFoundException("Employee with NIP " + emp.getNip() + " is deleted");
        }

        // check kalau NIP diganti & sudah dipakai orang lain
        if (!emp.getNip().equals(req.getNip()) && repo.existsByNip(req.getNip())) {
            throw new ConflictException("NIP " + req.getNip() + " is already used by another employee");
        }

        emp.setNip(req.getNip());
        emp.setName(req.getName());
        emp.setEmail(req.getEmail());
        emp.setJobTitle(req.getJobTitle());
        emp.setJobLevel(req.getJobLevel());
        emp.setUnitKerja(req.getUnitKerja());
        emp.setJoinDate(req.getJoinDate());
        emp.setStatus(req.getStatus());
        emp.setPhotoUrl(req.getPhotoUrl());

        return toResponse(repo.save(emp));
    }

    // ✅ Soft delete
    public void softDelete(Long id) {
        Employee emp = repo.findById(id)
                .orElseThrow(() -> new NotFoundException("Employee not found"));

        if (emp.getDeletedAt() != null) {
            throw new NotFoundException("Employee with NIP " + emp.getNip() + " is already deleted");
        }

        emp.setDeletedAt(Instant.now());
        repo.save(emp);
    }

    // ✅ Mapper
    private EmployeeResponse toResponse(Employee e) {
        return EmployeeResponse.builder()
                .id(e.getId())
                .nip(e.getNip())
                .name(e.getName())
                .email(e.getEmail())
                .jobTitle(e.getJobTitle())
                .jobLevel(e.getJobLevel())
                .unitKerja(e.getUnitKerja())
                .joinDate(e.getJoinDate())
                .status(e.getStatus())
                .photoUrl(e.getPhotoUrl())
                .createdAt(e.getCreatedAt())
                .updatedAt(e.getUpdatedAt())
                .deletedAt(e.getDeletedAt())
                .build();
    }
}