package com.bankmega.certification.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PicCertificationRequestDTO {
    private Long userId;
    private Long certificationId;
    private Long subFieldId; // optional
}
