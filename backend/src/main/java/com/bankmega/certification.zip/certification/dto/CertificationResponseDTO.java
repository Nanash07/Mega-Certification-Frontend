package com.bankmega.certification.dto;

import java.time.LocalDateTime;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CertificationResponseDTO {
    private Long id;
    private String name;
    private String code;
    private Boolean isWajib6bln;
    private Integer masaBerlaku;
    private Integer reminderMonth;
    private Boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt; 
}
