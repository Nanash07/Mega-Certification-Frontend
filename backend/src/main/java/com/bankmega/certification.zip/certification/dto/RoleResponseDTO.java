package com.bankmega.certification.dto;

import lombok.*;

@Getter @Setter @Builder
public class RoleResponseDTO {
    private Long id;
    private String name;
}
