package com.bankmega.certification.controller;

import com.bankmega.certification.dto.PicCertificationScopeRequest;
import com.bankmega.certification.dto.PicCertificationScopeResponse;
import com.bankmega.certification.service.PicCertificationScopeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pic-certifications")
public class PicCertificationScopeController {

    @Autowired
    private PicCertificationScopeService service;

    // Ambil semua scope PIC berdasarkan userId
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<PicCertificationScopeResponse>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(service.getByUser(userId));
    }

    // Tambah scope baru
    @PostMapping
    public ResponseEntity<PicCertificationScopeResponse> create(@RequestBody PicCertificationScopeRequest req) {
        return ResponseEntity.ok(service.create(req));
    }

    // Hapus scope
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}