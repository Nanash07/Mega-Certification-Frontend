package com.bankmega.certification.controller;

import com.bankmega.certification.dto.PicCertificationRequestDTO;
import com.bankmega.certification.dto.PicCertificationResponseDTO;
import com.bankmega.certification.service.PicCertificationService;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pic-certifications")
@RequiredArgsConstructor
public class PicCertificationController {

    private final PicCertificationService service;

    @GetMapping
    public List<PicCertificationResponseDTO> getAll() {
        return service.getAll();
    }

    @GetMapping("/user/{userId}")
    public List<PicCertificationResponseDTO> getByUserId(@PathVariable Long userId) {
        return service.getByUserId(userId);
    }

    @GetMapping("/{id}")
    public PicCertificationResponseDTO getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    public PicCertificationResponseDTO create(@RequestBody PicCertificationRequestDTO dto) {
        return service.create(dto);
    }

    @PutMapping("/{id}")
    public PicCertificationResponseDTO update(@PathVariable Long id, @RequestBody PicCertificationRequestDTO dto) {
        return service.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deletePicCertification(id); // kalau ga ketemu, throw RuntimeException
        return ResponseEntity.noContent().build();
    }
    
}
