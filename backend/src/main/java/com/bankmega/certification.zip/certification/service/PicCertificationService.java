package com.bankmega.certification.service;

import com.bankmega.certification.dto.PicCertificationRequestDTO;
import com.bankmega.certification.dto.PicCertificationResponseDTO;
import com.bankmega.certification.entity.*;
import com.bankmega.certification.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PicCertificationService {

    private final PicCertificationRepository repo;
    private final UserRepository userRepo;
    private final CertificationRepository certRepo;
    private final SubFieldRepository subFieldRepo;

    public List<PicCertificationResponseDTO> getAll() {
        return repo.findAll().stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    public List<PicCertificationResponseDTO> getByUserId(Long userId) {
        return repo.findAllByUserId(userId).stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    public PicCertificationResponseDTO getById(Long id) {
        return repo.findById(id)
                .map(this::toResponseDTO)
                .orElseThrow(() -> new RuntimeException("Mapping PIC Certification not found!"));
    }

    public PicCertificationResponseDTO create(PicCertificationRequestDTO dto) {
        User user = userRepo.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found!"));
        Certification cert = certRepo.findById(dto.getCertificationId())
                .orElseThrow(() -> new RuntimeException("Certification not found!"));

        SubField subField = null;
        if (dto.getSubFieldId() != null) {
            subField = subFieldRepo.findById(dto.getSubFieldId())
                    .orElseThrow(() -> new RuntimeException("Sub bidang not found!"));
            if (!subField.getCertification().getId().equals(cert.getId())) {
                throw new RuntimeException("Sub bidang tidak sesuai jenis sertifikasi");
            }
        }

        PicCertification mapping = PicCertification.builder()
                .user(user)
                .certification(cert)
                .subField(subField)
                .createdAt(LocalDateTime.now())
                .build();

        return toResponseDTO(repo.save(mapping));
    }

    public PicCertificationResponseDTO update(Long id, PicCertificationRequestDTO dto) {
        PicCertification mapping = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Mapping PIC Certification not found!"));
        User user = userRepo.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found!"));
        Certification cert = certRepo.findById(dto.getCertificationId())
                .orElseThrow(() -> new RuntimeException("Certification not found!"));

        SubField subField = null;
        if (dto.getSubFieldId() != null) {
            subField = subFieldRepo.findById(dto.getSubFieldId())
                    .orElseThrow(() -> new RuntimeException("Sub bidang not found!"));
            if (!subField.getCertification().getId().equals(cert.getId())) {
                throw new RuntimeException("Sub bidang tidak sesuai jenis sertifikasi");
            }
        }

        mapping.setUser(user);
        mapping.setCertification(cert);
        mapping.setSubField(subField);
        // mapping.setCreatedAt(mapping.getCreatedAt()); // Tidak perlu, created_at biarin original

        return toResponseDTO(repo.save(mapping));
    }

    public void deletePicCertification(Long id) {
        PicCertification pic = repo.findById(id)
            .orElseThrow(() -> new RuntimeException("PIC Certification not found!"));
        repo.delete(pic);
    }

    // Helper
    private PicCertificationResponseDTO toResponseDTO(PicCertification entity) {
        return PicCertificationResponseDTO.builder()
                .id(entity.getId())
                .userId(entity.getUser() != null ? entity.getUser().getId() : null)
                .username(entity.getUser() != null ? entity.getUser().getUsername() : null)
                .certificationId(entity.getCertification() != null ? entity.getCertification().getId() : null)
                .certificationName(entity.getCertification() != null ? entity.getCertification().getName() : null)
                .subFieldId(entity.getSubField() != null ? entity.getSubField().getId() : null)
                .subFieldName(entity.getSubField() != null ? entity.getSubField().getName() : null)
                .createdAt(entity.getCreatedAt())
                .build();
    }
}
