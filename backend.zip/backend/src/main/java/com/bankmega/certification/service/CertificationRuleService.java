package com.bankmega.certification.service;

import com.bankmega.certification.dto.CertificationRuleRequest;
import com.bankmega.certification.dto.CertificationRuleResponse;
import com.bankmega.certification.entity.Certification;
import com.bankmega.certification.entity.CertificationLevel;
import com.bankmega.certification.entity.CertificationRule;
import com.bankmega.certification.entity.SubField;
import com.bankmega.certification.exception.NotFoundException;
import com.bankmega.certification.repository.CertificationLevelRepository;
import com.bankmega.certification.repository.CertificationRepository;
import com.bankmega.certification.repository.CertificationRuleRepository;
import com.bankmega.certification.repository.SubFieldRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CertificationRuleService {

    private final CertificationRuleRepository repo;
    private final CertificationRepository certRepo;
    private final CertificationLevelRepository levelRepo;
    private final SubFieldRepository subFieldRepo;

    public List<CertificationRuleResponse> getAll() {
        return repo.findByDeletedAtIsNull().stream()
                .map(this::toResponse)
                .toList();
    }

    public CertificationRuleResponse getById(Long id) {
        CertificationRule rule = repo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new NotFoundException("Certification rule not found with id " + id));
        return toResponse(rule);
    }

    public CertificationRuleResponse create(CertificationRuleRequest req) {
        Certification cert = certRepo.findById(req.getCertificationId())
                .orElseThrow(() -> new NotFoundException("Certification not found with id " + req.getCertificationId()));

        CertificationLevel level = null;
        if (req.getLevelId() != null) {
            level = levelRepo.findById(req.getLevelId())
                    .orElseThrow(() -> new NotFoundException("Certification level not found with id " + req.getLevelId()));
        }

        SubField subField = null;
        if (req.getSubFieldId() != null) {
            subField = subFieldRepo.findById(req.getSubFieldId())
                    .orElseThrow(() -> new NotFoundException("Subfield not found with id " + req.getSubFieldId()));
        }

        CertificationRule rule = CertificationRule.builder()
                .certification(cert)
                .level(level)
                .subField(subField)
                .build();

        return toResponse(repo.save(rule));
    }

    public CertificationRuleResponse update(Long id, CertificationRuleRequest req) {
        CertificationRule rule = repo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new NotFoundException("Certification rule not found with id " + id));

        Certification cert = certRepo.findById(req.getCertificationId())
                .orElseThrow(() -> new NotFoundException("Certification not found with id " + req.getCertificationId()));
        rule.setCertification(cert);

        if (req.getLevelId() != null) {
            CertificationLevel level = levelRepo.findById(req.getLevelId())
                    .orElseThrow(() -> new NotFoundException("Certification level not found with id " + req.getLevelId()));
            rule.setLevel(level);
        } else {
            rule.setLevel(null);
        }

        if (req.getSubFieldId() != null) {
            SubField subField = subFieldRepo.findById(req.getSubFieldId())
                    .orElseThrow(() -> new NotFoundException("Subfield not found with id " + req.getSubFieldId()));
            rule.setSubField(subField);
        } else {
            rule.setSubField(null);
        }

        return toResponse(repo.save(rule));
    }

    public void softDelete(Long id) {
        CertificationRule rule = repo.findByIdAndDeletedAtIsNull(id)
                .orElseThrow(() -> new NotFoundException("Certification rule not found with id " + id));

        rule.setDeletedAt(Instant.now());
        repo.save(rule);
    }

    private CertificationRuleResponse toResponse(CertificationRule r) {
        return CertificationRuleResponse.builder()
                .id(r.getId())
                .certificationId(r.getCertification().getId())
                .certificationName(r.getCertification().getName())
                .levelId(r.getLevel() != null ? r.getLevel().getId() : null)
                .levelName(r.getLevel() != null ? r.getLevel().getName() : null)
                .subFieldId(r.getSubField() != null ? r.getSubField().getId() : null)
                .subFieldName(r.getSubField() != null ? r.getSubField().getName() : null)
                .createdAt(r.getCreatedAt())
                .updatedAt(r.getUpdatedAt())
                .build();
    }
}