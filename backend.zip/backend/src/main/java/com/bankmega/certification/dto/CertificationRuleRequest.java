package com.bankmega.certification.dto;

import lombok.Data;

@Data
public class CertificationRuleRequest {
    private Long certificationId;   // wajib
    private Long levelId;           // nullable
    private Long subFieldId;        // nullable
}