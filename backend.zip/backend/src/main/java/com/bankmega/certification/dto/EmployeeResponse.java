package com.bankmega.certification.dto;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.time.LocalDate;

@Data
@Builder
public class EmployeeResponse {
    private Long id;
    private String nip;
    private String name;
    private String email;
    private String jobTitle;
    private String jobLevel;
    private String unitKerja;
    private LocalDate joinDate;
    private String status;
    private String photoUrl;
    private Instant createdAt;
    private Instant updatedAt;
    private Instant deletedAt;
}