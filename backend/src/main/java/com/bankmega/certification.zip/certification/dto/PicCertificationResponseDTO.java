package com.bankmega.certification.dto;

import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PicCertificationResponseDTO {
    private Long id;
    private Long userId;
    private String username;
    private Long certificationId;
    private String certificationName;
    private Long subFieldId;
    private String subFieldName;
    private LocalDateTime createdAt;
}
