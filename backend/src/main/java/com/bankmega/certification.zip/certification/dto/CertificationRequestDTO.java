package com.bankmega.certification.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CertificationRequestDTO {
    private String name;
    private String code;
    private Boolean isWajib6bln;
    private Integer masaBerlaku;
    private Integer reminderMonth;
    private Boolean isActive;
}
