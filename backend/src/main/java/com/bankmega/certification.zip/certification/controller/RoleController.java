package com.bankmega.certification.controller;

import com.bankmega.certification.dto.RoleRequestDTO;
import com.bankmega.certification.dto.RoleResponseDTO;
import com.bankmega.certification.service.RoleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/roles")
@RequiredArgsConstructor
public class RoleController {

    private final RoleService roleService;

    // dropdown (tanpa paging)
    @GetMapping
    public List<RoleResponseDTO> getAll() {
        return roleService.getAll();
    }

    // table (paging + search ?q=)
    @GetMapping("/page")
    public Page<RoleResponseDTO> getPage(
            @RequestParam(required = false) String q,
            @PageableDefault(size = 10, sort = "name") Pageable pageable) {
        return roleService.getPage(q, pageable);
    }

    @GetMapping("/{id}")
    public RoleResponseDTO getById(@PathVariable Long id) {
        return roleService.getById(id);
    }

    @PostMapping
    public ResponseEntity<RoleResponseDTO> create(@Valid @RequestBody RoleRequestDTO dto,
                                                  UriComponentsBuilder b) {
        RoleResponseDTO saved = roleService.create(dto);
        URI location = b.path("/api/roles/{id}").buildAndExpand(saved.getId()).toUri();
        return ResponseEntity.created(location).body(saved);
    }

    @PutMapping("/{id}")
    public RoleResponseDTO update(@PathVariable Long id, @Valid @RequestBody RoleRequestDTO dto) {
        return roleService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        roleService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
